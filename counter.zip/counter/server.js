var express = require('express');
var body_parser = require('body-parser');
var session = require('express-session');
var app = express();

app.use(body_parser.urlencoded({extended: true}));
app.use(express.static(__dirname + '/static'));
app.use(session({secret: 'codingisawesome'}));

app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.get('/', function(request, response) {
    if ('count' in request.session) {
        request.session.count ++;
    } else {
        request.session.count = 1;
    }
    response.render('index', {count: request.session.count});
});

app.get('/add_count_by_2', function(request, response) {
    request.session.count ++;
    response.redirect("/");
})

app.get('/reset', function(request,response) {
    delete request.session.count;
    response.redirect('/');
})

app.listen(8000, function() {
    console.log("Listening on port 8000");
});